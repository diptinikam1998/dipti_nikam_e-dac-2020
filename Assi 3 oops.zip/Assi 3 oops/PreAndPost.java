/// Perform various expressions in order to understand the pre and post increment
operators.

class PreAndPost
{
public static void main(String args[])
{
int a=5;
int b=4;
int c;
int d;
c=b++;
d=++a;
int y;
y=a++ - ++b;
System.out.println(" a = "+a+" b = "+b+" c = "+c+" d = "+d);
System.out.println(" y = "+y+" a = "+a+" b = "+b);
System.out.println(++a);
System.out.println(b++);
}
}

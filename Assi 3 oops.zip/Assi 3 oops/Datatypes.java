///Execute an example to understand various Datatypes in Java with their default
values

class Datatypes
{
public static void main(String args[])
{
int a=20;
short s=45;
byte b=7;
long l=5243621;
float f=65.20286f;
double d=876.765f;
System.out.println("The Integer value is : "+a);
System.out.println("The Short value is : "+s);
System.out.println("The long value is : "+l);
System.out.println("The float value is : "+f);
System.out.println("The double value is : "+d);
}
}
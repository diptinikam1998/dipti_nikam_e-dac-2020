///Understand an array to display n value

import java.util.Scanner;
class Array
{
public static void main(String args[])
{
int arr[]=new int[10];
Scanner scan=new Scanner(System.in);
System.out.println("Enter the number:");
for(int i=0;i<10;i++)
{
arr[i]=scan.nextInt();
}
System.out.println("Value!!!!!!");
for(int i=0;i<arr.length;i++)
{
System.out.println(arr[i]);
}
}
}
import java.util.Scanner;
class OddEven
{
public static void main(String args[])
{
int i,n;
Scanner scan=new Scanner(System.in);
System.out.println("Enter the number:");
n=scan.nextInt();
if(n%2==0)
{
System.out.println("Even number");
}
else
{
System.out.println("Odd number");
}
}
}
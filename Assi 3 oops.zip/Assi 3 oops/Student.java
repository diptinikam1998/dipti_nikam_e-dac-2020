
///  Perform upcasting and downcasting with suitable example on primitive datatypes.

class Student
{
public static void main(String args[])
{
int i=20;
String name;
float f;
System.out.println("Hiii Student!!!!!!!!");
f=i; //Upcasting
System.out.println(f);
//downcasting
float f1=20.00f;
int rollNo;
i=(int)f1;
System.out.println(i);
}
}

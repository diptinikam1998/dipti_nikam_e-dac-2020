//Print different number series

import java.util.Scanner;
class Prime
{

public static void main(String args[])
{
int n,i,res;
boolean flag=true;
Scanner scan=new Scanner(System.in);
System.out.println("Enter the number:");
n=scan.nextInt();
for(i=2;i<=n/2;i++)
{
res=n%2;
if(res==0)
{
flag=false;
break;
}
}
if(flag)
System.out.println("Prime number");
else
System.out.println("Not prime number");
}
}
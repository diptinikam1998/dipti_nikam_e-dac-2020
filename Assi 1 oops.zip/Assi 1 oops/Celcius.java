import java.util.*;
class Celcius
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("input in Fahrenheit");
double Fahrenheit=sc.nextDouble();
double celcius=((5*(Fahrenheit-32.0))/9.0);
System.out.println(Fahrenheit + "degree Fahrenheit is equal to" +celcius+ "in cel");
}
}
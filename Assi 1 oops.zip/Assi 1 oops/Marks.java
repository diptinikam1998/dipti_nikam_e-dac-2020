////Q.07 Write a program to calculate sum of 5 subject’s marks & find percentage. Take the obtained marks from user using Scanner class. 
     //    Output should be in this format [ percentage marks = 99 % ]. Use concatenation operator here

import java.util.*;
class Marks
{
public static void main(String args[])
{
Scanner  sc=new Scanner(System.in);
int cdac1,cdac2,cdac3,cdac4,cdac5;
float total,percentage;
System.out.println("enter the marks");
cdac1=sc.nextInt();
cdac2=sc.nextInt();
cdac3=sc.nextInt();
cdac4=sc.nextInt();
cdac5=sc.nextInt();
total=cdac1+cdac2+cdac3+cdac4+cdac5;
percentage=(total/500)*100;
System.out.println("total marks: " +total);
System.out.println("percentage: " +percentage);
}
}


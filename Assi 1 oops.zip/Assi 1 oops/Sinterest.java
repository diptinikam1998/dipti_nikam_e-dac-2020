////Q 08.	Write a program to find the simple interest. Take the principle amount, rate of interest and time 
                //from user using Scanner class.

import java.util.*;
class Sinterest
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
float p,r,t,sinterest;
System.out.println("Enter the principal");
p=sc.nextFloat();
System.out.println("Enter the rate of interest");
r=sc.nextFloat();
System.out.println("Enter the time period");
t=sc.nextFloat();
sinterest=(p*r*t/100);
System.out.println("simple interest is : " +sinterest);
}
}
/*03.	Find the result of following expressions. You need to determine the primitive data type of the variable by looking carefully the given expression and initialize variables by any random value.
A. y = x2 + 3x - 7 (print value of y) 
B. y = x++ + ++x (print value of x and y) 
C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]*/


class Addition
{
/*public static void main(String args[])
{
int x=5;
int y = (x*x+3*x-7);
System.out.println(y);
}
}*/


/*public static void main(String args[])
{
int x=3;
int y = (x++ + ++x);
System.out.println(y);
}
}*/

public static void main(String args[])
{
int x=2;
int y=3;
int z = (x++ - --y - --x  +  x++); 
System.out.println(z);
}
}
/*public static void main(String args[])
{

boolean x=false;
boolean y=false;
z = x && y || !(x || y);
System.out.println(z);
}
}*/


///Q 13.	Program to find greatest in 3 numbers[ once using if else statement and then using ternary operator ( logical operator) ]  

class Number
{
public static void main(String args[])
{
int a=10,b=20,c=5;
if (a>b && a>c)
System.out.println(a);
else if
(a>c && b>c)
System.out.println(b);
else 
System.out.println(c);
}
}




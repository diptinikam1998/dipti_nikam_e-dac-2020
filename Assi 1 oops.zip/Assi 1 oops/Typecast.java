
////04.::Write a program that initializes 2 byte type of variables. Add the values of these variables and store
 // in a byte type of variable
class Typecast
 {
 public static void main(String args[]) {
  byte num1=5;
  byte num2=6;
byte add =(byte)(num1+num2);
  System.out.println("addition of two byte numbers is "+add);
 }
}

///06.	Write a program that takes radius of a circle as input. Read the entered radius using Scanner class.
  ///       Then calculate and print the area and circumference of the circle.

import java.util.*;
class Circle
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the radius");
int radius=sc.nextInt();
int area= Math.PI*(radius*radius);
System.out.println("The area of circle is: "+area);
int circumference=Math.PI*2*radius;
System.out.println("The circumference of circle is: "+circumference);
}
}


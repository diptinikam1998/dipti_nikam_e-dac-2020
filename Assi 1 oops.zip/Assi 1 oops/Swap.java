
////Q 11 Write a program to swap two numbers without using third variable.
import java.util.*;
class Swap
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int x = sc.nextInt();
int y = sc.nextInt();
System.out.println("before swapping "+x+" "+y);
x=x+y;
y=x-y;
x=x-y;
System.out.println("after swapping "+x+" "+y);
}
}
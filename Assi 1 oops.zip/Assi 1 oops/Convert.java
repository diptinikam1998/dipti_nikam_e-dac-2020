class Convert
{
public static void main(String args[])
{
Short a=10;
Byte b=20;
b=(Byte a)(a+b);
System.out.println(b);
}
}

class Marriage
{
	public static void main (String[] args) {
		
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter age");
		int age = sc.nextInt();
		
		System.out.println("Enter sex: M/F");
		int sex = sc.next().charAt(0);
		
		System.out.println("Are you married? Y/N");
		int married = sc.next().charAt(0);
		}
		if(sex == 'M') {
			if((age >= 21) && (age <25)
			{
				System.out.println("You are eliigible for marriage");
			}
			else {
				System.out.println("You are not eligible for marriage");
			
		}
	}
}
	interface College
	{
	void displayResult();
	}
	interface Exam
	{
	void displayResult();
	}
	class Student implements College,Exam
	{
		public void displayResult()
                {
                 System.out.println("you got 75%");
		}
		
	public static void main(String args[])
	{
		College clg;
		clg=new Student();
		Student.displayResult();
	}
	}
	
	interface School
	{
		void learning();
		void teaching();
	}
	class Student implements School
	{
	public void learning()
	{
		System.out.println("Students are good");
	}
	
	public void teaching()
	{
		System.out.println("Teachers are good in knowledge");
	}
	}
	class Teacher
	{
	public static void main(String args[])
	{
	School sch;
	sch=new Student();
	sch.learning();
	}
	}
	
	
	
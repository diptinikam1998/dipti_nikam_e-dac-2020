 	class Employee
	{
		String empName;
		int empNo;
		int empSalary;
	Employee(String name,int no,int sal)	
	{
		empName=name;
		empNo=no;	
		empSalary=sal;
	}
	public void employeeData()
	{
		System.out.println("Empname ="+empName);
		System.out.println("Empno ="+empNo);
		System.out.println("Empsalary ="+empSalary);
	}
	}
	class manager extends Employee
	{
	          int reward;
		public manager(String name,int no,int sal,int s)
		{
			super(name,no,sal);
			reward=s;
		}
	
	public void managerData()
	{
		System.out.println("Empname ="+empName);
		System.out.println("Empno ="+empNo);
		System.out.println("Empsalary ="+empSalary);
		System.out.println("Reward ="+reward);
	}
	}
	class worker extends Employee
	{
		int bonus;
		public worker(String name,int no,int sal,int p)
		{
		super(name,no,sal);
		bonus=p;
	}
	public void workerData()
	{
		System.out.println("Empname ="+empName);
		System.out.println("Empno ="+empNo);
		System.out.println("Empsalary ="+empSalary);
		System.out.println("Bonus ="+bonus);
	}
	}
	class Test
	{
	public static void main(String args[])
	{
	  Employee emp=new Employee("dipti",1,50000);
	  emp.employeeData();
	  manager man=new manager("dipti1",2,1000000,20000);
	  man.managerData();
	}
	}

			
		


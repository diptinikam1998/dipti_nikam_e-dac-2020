	interface Company
	{
		String empName = "Dipti";
		int Salary = 10000;
		void empDetails();
		void empSalary();
	}
	class Employee implements Company{
		public void empDetails()
		{
			System.out.println("employee name is dipti");
		}
	
		public void empSalary()
		{
			System.out.println("employee salary is 10000");
		}
	}
	class Salary implements Company{
		public void empDetails()
		{
			System.out.println("employee city is mumbai");
		}
	
		public void empSalary()
		{
			System.out.println("employee name is dipti");
		}
	}
	class TestInterface{
	public static void main(String args[])
	{
	Employee emp=new Employee();
	emp.empDetails();
	}
	} 
	class BankAccount
	{
	public void checkBalance()
	{
		System.out.println("your balance is 10000");
	}
	public void viewDetails()
	{
		System.out.println("Name: Dipti nikam");
		System.out.println("Address: 123 main road");
	}
	}
	class customer extends BankAccount
	{
	public void customerSavingAmount()
	{
		System.out.println("saving ammount is 10000");

	}
	}
	class TestDetails
	{
	public static void main(String args[])
	{
	 customer cus=new customer();
	 cus.checkBalance();
	 cus.viewDetails();
	}
	}	
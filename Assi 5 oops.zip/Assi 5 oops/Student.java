	interface College
	{
	void Result();
	}
	interface Exam
	{
	void Result();
	}
	class Student implements College,Exam{
		public void Result()
                {
                 System.out.println("you got 75%");
		}
		
	public static void main(String args[])
	{
	
		Student obj=new Student();
		obj.Result();
	}
	}
	
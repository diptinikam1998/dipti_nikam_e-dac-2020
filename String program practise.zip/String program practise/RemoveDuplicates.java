//14) How to remove duplicate characters from String?

import java.util.*;
class RemoveDuplicates
{
static void removeDupChar(String str)
{
LinkedHashSet<Character> set=new LinkedHashSet<>();
for(int i=0;i<str.length();i++)
set.add(str.charAt(i));

for(Character ch:set)
System.out.print(ch);
}

public static void main(String args[])
{
String str = "Diptinikam";
removeDupChar(str);
}
}
import java.util.Arrays;

public class StringAnagram 
{
public static void main(String args[])
{
isAnagram("word","drow");

}

public static void isAnagram(String word,String anagram)
{
char[] wordArray = word.toCharArray();
char[] anagramArray = anagram.toCharArray();
Arrays.sort(wordArray);
Arrays.sort(anagramArray);
if(Arrays.equals(wordArray,anagramArray))
{
System.out.println("two string are anagram");
}

else
{
System.out.println("two strings are not anagram");
}
}
}



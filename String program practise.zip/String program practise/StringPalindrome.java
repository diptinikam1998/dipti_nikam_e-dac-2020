//13)How to check if String is Palindrome? 

class StringPalindrome
{
static boolean isPalindrome(String str)
{
int i=0, j=str.length()-1;

while(i<j)
{
if(str.charAt(i) != str.charAt(j))
return false;
i++;
j--;
}

return true;
}
public static void main(String args[])
{
String str = "mom";
if(isPalindrome(str))
System.out.print("yes");
else
System.out.print("no");
}
}
//==============================================================================
//second approach using string buffer

public class StringPalindrome {
   public static void main(String args[]){

      String myString = "anna";
      StringBuffer buffer = new StringBuffer(myString);
      buffer.reverse();
      String data = buffer.toString();
      if(myString.equals(data)){
         System.out.println("Given String is palindrome");
      }else{
         System.out.println("Given String is not palindrome");
      }
   }
}
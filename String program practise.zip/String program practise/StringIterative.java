//1)How to reverse String in Java using Iteration and Recursion?

//1)Iterative approach
/*class StringIterative
{
static void reverseStr(String str)
{
int n = str.length();
char[]ch = str.toCharArray();
char temp;

for(int i=0, j=n-1; i<j; i++, j--)
{
temp = ch[i];
ch[i] = ch[j];
ch[j] = temp;
}

System.out.println(ch);
}

public static void main(String args[])
{
String str = "shekhar";
 str= String.join(" ", str.split(""));
reverseStr(str);
}
}*/

//=====================================================================================

//2)Recursive approach

class StringRecursive
{
 
static void recursiveReverse(char[] str, int i)
{
    int n = str.length;
    if (i == n / 2)
        return;
    swap(str,i,n - i - 1);
    recursiveReverse(str, i + 1);
}
static char[] swap(char []arr, int i, int j)
{
    char temp= arr[i];
    arr[i]=arr[j];
    arr[j]=temp;
    return arr;
}
 
// Driver program
public static void main(String[] args)
{
    char[] str = "geeksforgeeks".toCharArray();
    recursiveReverse(str,0);
    System.out.println(String.valueOf(str));
}
}
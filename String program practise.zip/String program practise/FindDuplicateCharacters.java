//6) How to find duplicate characters count in a given String?
//For example, if given String is "Programming" then your program should print
//g : 2
//r : 2
//m : 2

import java.util.HashMap; 
import java.util.Map; 
import java.util.Scanner;
import java.util.Set;

public class FindDuplicateCharacters {
       public static void main(String[] args) {
              Scanner scanner = new Scanner(System.in);
              System.out.println("Enter any value: ");
              printDuplicateCharacters(scanner.nextLine());
              printDuplicateCharacters(scanner.next());
       }

       public static void printDuplicateCharacters(String word) {
              char[] charecters = word.toCharArray();

              Map<Character, Integer> map = new HashMap<Character, Integer>();
              for (Character ch : charecters) {
                     if (map.containsKey(ch)) {
                           map.put(ch, map.get(ch) + 1);
                     } else {
                           map.put(ch, 1);
                     }
              }
              System.out.printf("list of duplicate charecter of string '%s'%n", word);
              for(Map.Entry<Character, Integer> entry : map.entrySet()) {
                     if (entry.getValue() > 1) {
                           System.out.printf("%s : %d %n", entry.getKey(), entry.getValue());
                     }
              }

       }
}
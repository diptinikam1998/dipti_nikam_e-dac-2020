///10.	Write the program to find the sum of even elements and sum of odd 
    elements present in the array of integer type.

import java.util.Scanner;
class Sum_Odd_Even
{
public static void main(String args[])
{
int n,sumE=0,sumO=0;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number of array:");
n=sc.nextInt();
int arr[]=new int[n];
System.out.println("Enter the elements of array:");
for(int i=0;i<n;i++)
{
arr[i]=sc.nextInt();
}
for(int i=0;i<n;i++)
{
if(arr[i]%2==0)
{
sumE=sumE+arr[i];
}
else
{
sumO=sumO+arr[i];
}
}
System.out.println("sum of Even number:"+sumE);
System.out.println("sum of Odd number:"+sumO);
}
}

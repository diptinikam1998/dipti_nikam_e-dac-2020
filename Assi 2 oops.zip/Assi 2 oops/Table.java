///1	Write a program to print table of any entered number using loop.


import java.util.Scanner;
class Table
{
public static void main(String args[])
{
int x,y,z;
Scanner scan=new Scanner(System.in);
System.out.println("Enter the table number:");
int num=scan.nextInt();
for(int i=1;i<=10;i++)
{
System.out.println(num+ " x "+i+ " = "+num*i);
}
}
}
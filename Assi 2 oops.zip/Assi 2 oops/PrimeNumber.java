/////5) Print all prime numbers between two given numbers. [ break continue ]

import java.util.Scanner;
class PrimeNumber
{
public static void main(String args[])
{
int i,j,a,b,flag;
Scanner scan=new Scanner(System.in);
System.out.println("Enter the first:");
a=scan.nextInt();
System.out.println("Enter the second:");
b=scan.nextInt();
System.out.println("Prime Number:");
for(i=a;i<=b;i++)
{
if(i==1 || i==0)
{
continue;
}
flag=1;
for(j=2;j<=i/2;++j)
{
if(i%j==0)
{
flag=0;
break;
}
}
if(flag==1)
{
System.out.println(i);
}
}
}
}
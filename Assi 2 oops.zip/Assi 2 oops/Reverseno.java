///Write a program to reverse a given number.


import java.util.Scanner;
class Reverseno
{
public static void main(String args[])
{
int num=0;
int reversenum=0;
Scanner sc=new Scanner(System.in);
System.out.println("enter the number");
num=sc.nextInt();
while(num!=0)
{
reversenum=reversenum*10;
reversenum=reversenum+num%10;
num=num/10;
}
System.out.println("Reverse of number " +reversenum);
}
}




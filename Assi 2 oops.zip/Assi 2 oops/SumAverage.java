///6.	Program to show sum and average of 10 element array. Accept array elements from user. 

import java.util.Scanner;
class SumAverage
{
public static void main(String args[])
{
int n,sum=0;
float avg;
Scanner scan=new Scanner(System.in);
System.out.println("Enter the elements:");
n=scan.nextInt();
int arr[]=new int[n];
System.out.println("Enter the All elements:");
for(int i=0;i<n;i++)
{
arr[i]=scan.nextInt();
sum=sum+arr[i];
}
System.out.println("Sum:"+sum);
avg=(float)sum/n;
System.out.println("avg:"+avg);
}
}